---
title: Bucket List (Books)
subtitle: Books that I'd be reading in 2019
layout: "page"
icon: fa-book
order: 5
---


1. [ ] Twelve against the gods: William Bolitho Ryall (Suggested by [Subham Pasari](https://www.facebook.com/36.subham))
2. [X] The 48 Laws of Power: Robert Greene
3. [ ] Elon Musk: ASHLEE VANCE
4. [ ] The 4-Hour Body: Tim Ferriss
5. [ ] The 4-Hour Chef: Tim Ferriss
6. [ ] Educated: Tara Westover [Bill Gates list of 2018](https://www.gatesnotes.com/About-Bill-Gates/Best-Books-2018)
7. [ ] Army of None: Paul Scharre
8. [ ] Bad Blood: John Carreyrou
9. [ ] 21 Lessons for the 21st Century: Yuval Noah Harari
10. [ ] The Headspace Guide to Meditation and Mindfulness: Andy Puddicombe
11. [ ] The Code of Extraordinary mind: Vishen Lakhiani
12. [ ] Stumbling on Happiness: Daniel Gilbert
13. [ ] Thinking Fast and Slow: Daniel Kahneman
14. [ ] Talk is Cheap: James E. Gaskin
15. [ ] Blink: The Power of Thinking without Thinking: Malcolm Gladwell
16. [ ] Finish: Give Yourself the Gift of Done: Jon Acuff
17. [ ] Think and Grow Rich: Napolean Hill
18. [ ] Superintelligence: Paths, Dangers, Strategies: Nick Bostrom
19. [ ] Steve Jobs: Walter Isaacson
20. [ ] Autobiography of a Yogi: Yogananda, Paramahansa
21. [ ] How to Read a Person Like a Book: Observing Body Language to Know What People Are Thinking
22. [ ] Programming Pearls: Jon Bentley
23. [ ] Pragmatic Programmer: Andrew Hunt and David Thomas
24. [ ] CODE COMPLETE: Steve McConnell
25. [ ] Inner Engineering: A Yogi's guide to joy (Sadguru)
26. [ ] Sapiens: A brief history of Humankind: Yuval Noah Harari


I am running far behind with respect to this list. Let's just keep this intact in the original format. :) #FingersCrossed