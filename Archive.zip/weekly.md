---
title: Contrivances
subtitle: Things that I found interesting, uselful
layout: "page"
icon: fa-pencil-square-o
order: 4
---

1. Knowledge Sharing:
  * Medium: Elaborated topics minimum 10 minute read (but are worth it).
  * Quora: Question specific knowledge, helps in understanding different views (5-10 minutes must per day).
2. Note taking: Microsoft OneNote (Notebook --> Sections --> Pages), complex than Evernote but fancy and handy to use.
3. Editor:
  * VS Code: Versatile, has terminal window, good folder structure, a lot of plugins.
  * Sublime Text: Simple and powerful.
  * Vim: If you want to be a God. (Looking forward to it for 'Only Keyboard mode, touchpad is not allowed for anything')
4. Laptop: Macbook (Hands down does thing far smoothly than any other machine.)
5. Mind Maps: Coggle (colorful and can be shared easily)
6. Smartband: 
  * Mi Band 2: Had it for almost 2 years. A great band. (Mi Band 3 is showing promise too).
  * Honor Band 4: Colorful, additional functionalities, Unmatched heart rate and sleep tracker in its segment. 