---
title: Bucket List
subtitle: This weeks bucket list
layout: "page"
icon: fa-list
order: 3
---
#### For Month: April 2019
  * [ ] Consistency
  * [ ] Gratitude
  * [ ] 11k steps for 10 days

#### For Month: March 2019 (Will complete it soon :P)
  
  * [X] Change one thing about yourself: No lectures, No more correcting others (Top Priority :) )
  * [ ] Schematic for WiFi/Bluetooth connected Colorful Lights
  * [ ] Article on Medium
  * [ ] Juggling
  * [ ] 4 Hour Body - Tim Ferriss 
  * [ ] Rubik's Cube 
  * [X] Follow diet for 5 days

#### Things Crossed (Highlights):

  * [x] Zero to One - Blake Masters and Peter Thiel
  * [x] 4 hour work week - Tim Ferriss
  * [x] 100 kms of cycling
  * [X] The 48 Laws of Power: Robert Greene  
  * [x] Visit to Cubbon Park, Madiwala Lake, Agara Lake (and 2 others) on bicycle.
  * [x] Click 25+ images of sunrise and sunsets. [link to the album](https://photos.app.goo.gl/rViWvhUWfTMCjSuP7)
  * [x] Travel Solo
  * [x] Make a list of 5 healthy food items (Salads etc.)
  * [x] Have 10 perfect days
  * [x] Earn a certification
  * [x] Wake up at 6 am everyday

>What you get by achieving your goals is not as important as what you become by achieving your goals. - Zig Ziglar