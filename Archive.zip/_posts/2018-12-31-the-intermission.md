---
title: The Intermission
author: Hitesh Gautam *
layout: post
---

* Last day of the year! 
* Another year passed away.
* Resolutions!!!

At the beginning of the year I started making a list of things I wanted to do. When I reached at item 32, it seemed redundant. Learning languages, tech stacks, create DIY projects and what not, the list had different items but the all the things seemed to be converging at a point. I paused and decided to complete these first and then write the rest later.
Took quite a time to realize all those things were a child of expectations (from people and from myself) which I seem to magnify quite a lot.
>e.g. A IoT switch can be implemented on a bread-board, using led and a NodeMCU chip. But instead of a simple POC, I went and bought NeoPixels 5050 strip (thrice), Arduino, NodeMCU. (It's like upgrading to cheesy fries and float from a normal meal at MC Donalds.)

The result was beautiful but the purpose got lost. 

>Isn't the same thing is happening everywhere?

# New Year Resolutions coming up.