---
title: The Accessory
author: Hitesh Gautam *
layout: post
---

>Enjoy simple things in life

There are some quotes whose origin seem to be untraceable but I feel obligated to follow them. Now, I am feeling forced to list down all such quotes/phrases which I am following unconsciously, but they do direct a part of my life. (I will do this in my next post and might add some lessons associated with them).

I do like sipping tea while watching sunset/sunrise. Though the wires and the buildings do mess up the scene sometimes but still they can't spoil the most beautiful part of the day (A long breath and the scene does its magic anywhere).
Yes, watching it from a balcony of a five-star, on the deck of the ship in the middle of the ocean, amongst the hills with clouds or just driving down a road, each has its own experience ( All of them can be symbolised as career choices or summed up effect of life’s tests ), but running after an accessory wasn’t taught to me.
A lot of beliefs have been shattered and rebuilt in the recent past and this is a good sign, a sign of life and the change driving it forward. I still don’t know whether to focus on the serenity that the **Belt of the Venus** is giving me or to run after the accessories that might open a stimulus that I am not aware of. 
But this cycle of **Ending** and new **Beginning** will mesmerize whoever pauses and accepts the extent of time and universe.

**Till I/We figure it out, let's cherish what we have got today.**
