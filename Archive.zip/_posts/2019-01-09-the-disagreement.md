---
title: The Disagreement
author: Hitesh Gautam * *
layout: post
---

I don't agree with many(any) of the practices currently being followed in the whole world.
From lying (I get surprised when people justify this) to not giving your full, from cheating to getting more (than required) profit (this is also hypothetical), everything makes me feel uncomfortable. I used to think that not lying or not manipulating should be the default case scenario. Communication is the ladder that made us evolve from other primates and we have made that ladder a web. Imagine this, if there were no lies or in abstract terms 'No bad data', everything could have made sense, everything would have helped in our growth. 
**But if I correlate capitalism here then everyone has the right to be at his/her max. comfort and to be there you have the right to do anything.**
And I am being told that emotions are for pussies (cats -_-).
So, my level of emotional intelligence is not going to do any good and rather would harm me if I am surrounded by Predators (?). 
Or my disagreement lies with the lack of understanding of EQ, people, society, life. 
But this feeling of confusion and yearn to understand why everything is happening the way it is, does open new doors (which could have been locked forever).
In short:
>Consume information and be at a level (where you have principles, understanding etc.) from where you can identify where to question and where to stop following.

<br>

>The way this world is right now (considering it the best case scenario among all the permutations that could have left it in the worst state), everyone can follow whatever they want to (even create followers of your own). This is an interesting time we are living in, predictable but still surprising us on every turn.

<br>
#### P.S: (Abstract thought):
 Consider electrons as followers and nucleus as a leader (with the chain of protons (leaders) over a period of time). Followers surrounding the leader, who dared to accumulate knowledge over time and made his/her own element. And BTW are we done with the periodic table? No more elements to discover or create?

