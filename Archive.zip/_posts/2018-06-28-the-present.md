---
title: The Present
author: Hitesh Gautam ****
layout: post
---

I usually find myself in phases, defined by recurrence of something (can be an experience, smell, feeling or even an actor appearing in the movies that you find yourself seeing, everyday in my case). These phases seem to focussing on something that eventually I put into my "Archive". These days life has been giving emphasis on the word "Present". Whether it is Instagram, series I am currently watching : "This is us", or a scolding from mom (on acting lazy), I found myself appreciating the current moment. I have used different threads over past, present and future but now, I am trying to devise a way to focus on the present and have dedicated time for retrospection and planning.

Will continue on this later.

Note to self: Add section for movies, series with reviews.