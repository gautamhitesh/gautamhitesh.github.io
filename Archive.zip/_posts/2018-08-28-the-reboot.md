---
title: The Reboot
author: Hitesh Gautam ***
layout: post
---

Almost two months since the last post and so much has changed (in terms of perception). The weather of Bangalore, people, news and many such things show so subtle change that they look the same but a lot seems to have changed underneath. It's like an abstraction layer, making us to move forward, like the time making us to follow it, where ever it is leading us to.
Coming to simpler things traveling without planning is fun. From being an over prepared to be the most non-ready person on the planet, feels like quite a journey. For example, I am used to carry all kinds of denominations of currency so I never need to slow myself down for some transaction process we created (we could have been exchanging goods in good faith and having fun), but this time I had no cash and some random fellow passenger paid for me. I couldn't even ask his name, but for that humble anonymous I will carry cash always and pay for any person who is ready to dive into the world of traveling without thinking.