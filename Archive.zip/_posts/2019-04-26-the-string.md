---
title: The String
author: Hitesh Gautam * * * *
layout: post
---

No posts for so long.. it's not like anyone is desperately waiting for them (not yet :P). Still, I would like to explain (to myself) that I was working on implementing changes that I always wanted to. Also, I was testing the recipe I posted last time.  Following were the things I tried to bring some changes:
    
    1. Running and Cycling: [BREAK] The first step was to get exhausted. Wipe the disk clean in some way. Aren't similar practices used in Military training? I think I have seen a start-up on this: Somewhere they hire ex-army men to train people (cool!).
        This process is not completed yet. I can imagine the feelings of Gym Freaks now.

    2. Meditation: [Accept] 
    Not posing like a saint or acting like an enlightened person rather a simple technique of controlling the number of thoughts.
    Following takeaways:
        1. I am not my mind/thoughts rather I control my mind.
        2. Converting thoughts is more complicated than having less of them.
        3. Not something fancy. Just focussing on each breath and not getting carried away with thoughts.
        4. Far simple than what is being told just wait and practice it.
    There were no revelations but there a difference (before and after) can be felt. 

    3. Unlearn: Also done as a part of the above. Observing where to unplug yourself.
    4. Strike [yet to be done]
    5. Learn: [should be always on, let's put it in yet to be done]
    6. Repeat: Consistency is the key. So, this is a forever going action.

![One step at a time](https://drive.google.com/open?id=1RVxazWHA9uxTTOw-MThXTNJNcO3tKIsF)

There are challenges in the way (some might take 6 months to break), there are setbacks too and there are always numerous reasons not to do a thing, isn't it? I find everything connected from sunrise, chirping of birds to laughter among the friends in the hallway and not to mention everything that is in motion (water flowing, evening breeze etc).  :)
Emotions: Energy in Motion, (when you want it to make sense, it will!) can be used as a catalyst. So why not use it to bundle good things together. 
#### For this I don't think you will think about the strength of the string (your desire to do good), rather the things will make it stronger.
