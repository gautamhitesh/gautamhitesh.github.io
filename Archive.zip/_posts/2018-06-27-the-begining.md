---
title: The begining
author: Hitesh Gautam **
layout: post
---

This is the most promising start for my blog in years. Posted twice in blogspot, 5 times in wordpress, but I was never satisfied with them. Big thumbs up to the guy who introduced this idea in my life:
>We don't need motivation, we just need a fu@#ing reason.

That illuminated the significance of discipline, perseverance. I will try to post things up so that the required transformation comes quicker or I am able to make continuous progress. 

I want to add the following things into my blog:
1. [X] Bucket list (weekly)
2. [ ] Thought of the day
3. [X] Blog
4. [ ] Technical Notes
5. [ ] CV
6. [X] Movies List
7. [X] TV Series List