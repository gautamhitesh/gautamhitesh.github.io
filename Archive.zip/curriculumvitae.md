---
layout: blog
title: Curriculum Vitae
layout: "page"
icon: fa-file-text-o
order: 5
---
[Download](https://drive.google.com/open?id=1cuhWEuQYLSLBbiD6RNLRppjqT7i0YO_5)
<embed src="assets/cv1.pdf" width="800" height="575" type='application/pdf'>